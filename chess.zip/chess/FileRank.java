package chess;


/**
 * Write a description of class FileRank here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class FileRank
{
    ReturnPiece.PieceFile file;
    int rank;
    public FileRank(ReturnPiece.PieceFile file, int rank) {
        this.file = file;
        this.rank = rank;
    }
    
}
